create
    definer = root@localhost procedure salvar_cliente(IN ruacli varchar(100), IN cepcli int, IN numcli int,
                                                      IN baicli varchar(45), IN compcli varchar(45),
                                                      IN nomecli varchar(100), IN telcli int, IN logcli varchar(45),
                                                      IN senhacli varchar(45), IN statuscli varchar(10),
                                                      IN email varchar(100))
begin
		declare fkend int unsigned default 0;
    
		insert into endereco values (null, ruacli, cepcli, numcli, baicli, compcli);
        set fkend = last_insert_id();
        insert into cliente values (null, nomecli, telcli, logcli, senhacli, statuscli, email, fkend);
	end;

