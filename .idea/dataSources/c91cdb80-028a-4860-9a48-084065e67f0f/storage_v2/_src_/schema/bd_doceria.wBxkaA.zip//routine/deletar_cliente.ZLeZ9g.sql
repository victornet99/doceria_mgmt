create
    definer = root@localhost procedure deletar_cliente(IN id int)
begin
		delete from cliente where id_cliente = id;
        delete from endereco where id_endereco = id;
	end;

